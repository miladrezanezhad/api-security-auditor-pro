
# 🔒 API Security Auditor Pro

[![PyPI version](https://badge.fury.io/py/api-security-auditor-pro.svg)](https://badge.fury.io/py/api-security-auditor-pro)
[![PyPI downloads](https://img.shields.io/pypi/dm/api-security-auditor-pro)](https://pypi.org/project/api-security-auditor-pro/)
[![License](https://img.shields.io/github/license/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro)](https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/blob/main/LICENSE)
[![CI](https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/actions/workflows/ci.yml/badge.svg)](https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/actions/workflows/ci.yml)
[![Codecov](https://codecov.io/gh/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/branch/main/graph/badge.svg)](https://codecov.io/gh/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro)
[![GitHub stars](https://img.shields.io/github/stars/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro)](https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/stargazers)

**Professional command-line tool for comprehensive API security auditing with CI/CD integration.**

## 🚀 Features

- **10+ Security Checks**: SQL/NoSQL injection, XSS, IDOR, JWT vulnerabilities, rate limiting, CORS, security headers, data exposure, file upload, GraphQL
- **Multiple API Types**: REST, GraphQL, SOAP support
- **OpenAPI/Swagger Integration**: Automatically parse and test all endpoints
- **CI/CD Ready**: JUnit XML output for Jenkins/GitLab CI integration
- **Multiple Output Formats**: JSON, HTML, CSV, PDF, JUnit XML
- **Rate Limiting Testing**: Detect missing rate limiting with configurable concurrency
- **Passive Analysis**: Analyze proxy logs and PCAP files
- **Custom Plugins**: Extend functionality with Python plugins
- **Docker Support**: Run in containers with ease

## 📦 Installation

### From PyPI (Recommended)

```bash
pip install api-security-auditor-pro
```

### From Source

```bash
git clone https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro.git
cd api-security-auditor-pro
pip install -e .
```

### Using Docker

```bash
docker pull [YOUR_DOCKER_USERNAME]/api-security-auditor-pro:latest
docker run [YOUR_DOCKER_USERNAME]/api-security-auditor-pro --help
```

## 🎯 Quick Start

### Basic API Scan

```bash
# Scan a single endpoint
api-auditor scan https://api.example.com/users

# With verbose output
api-auditor scan https://api.example.com/users --verbose

# Save results to HTML report
api-auditor scan https://api.example.com/users --output report.html --format html
```

### Complete API Audit from OpenAPI Spec

```bash
# Audit all endpoints from OpenAPI specification
api-auditor audit --spec ./openapi.yaml

# Skip specific checks
api-auditor audit --spec ./openapi.yaml --skip-checks rate_limiting,data_exposure

# Run only specific checks
api-auditor audit --spec ./openapi.yaml --checks sql_injection,idor
```

### Test Rate Limiting

```bash
# Test with 1000 requests, 50 concurrent connections
api-auditor test-rate-limit https://api.example.com/login --requests 1000 --concurrency 50
```

### Passive Analysis

```bash
# Analyze proxy logs (Burp Suite, OWASP ZAP)
api-auditor analyze --log-file burp.log

# Analyze PCAP file
api-auditor analyze --pcap-file traffic.pcap --output analysis.json
```

## 🛠️ Command Reference

### Global Options

| Option | Description |
|--------|-------------|
| `--help` | Show help message |
| `--version` | Show version information |

### Scan Command

```bash
api-auditor scan URL [OPTIONS]
```

| Option | Description | Default |
|--------|-------------|---------|
| `-v, --verbose` | Enable verbose output | False |
| `-o, --output` | Output file path | None |
| `-f, --format` | Output format (json/html/csv/pdf) | json |
| `-t, --timeout` | Request timeout in seconds | 30 |
| `-th, --threads` | Number of concurrent threads | 10 |
| `-c, --checks` | Comma-separated checks to run | all |
| `-s, --skip-checks` | Comma-separated checks to skip | none |

### Audit Command

```bash
api-auditor audit --spec PATH [OPTIONS]
```

| Option | Description | Required |
|--------|-------------|----------|
| `--spec` | OpenAPI/Swagger file path | Yes |
| `-o, --output` | Output file path | No |
| `-f, --format` | Output format | json |
| `-c, --checks` | Specific checks to run | No |
| `-k, --skip-checks` | Checks to skip | No |

## 📊 Security Checks Reference

| ID | Check | Severity | Description |
|----|-------|----------|-------------|
| INJ001 | SQL Injection | CRITICAL | Detect SQL injection vulnerabilities |
| INJ002 | NoSQL Injection | CRITICAL | Detect NoSQL injection in MongoDB/others |
| INJ003 | XSS | MEDIUM | Cross-site scripting in API responses |
| AUTH001 | JWT Weak Signature | HIGH | Weak JWT secrets or none algorithm |
| AUTH002 | IDOR/BOLA | HIGH | Insecure Direct Object References |
| RATE001 | Missing Rate Limiting | MEDIUM | No rate limiting protection |
| HEAD001 | Security Headers | LOW | Missing security headers |
| HEAD002 | CORS Misconfiguration | MEDIUM | Overly permissive CORS policies |
| DATA001 | Data Exposure | HIGH | Sensitive data in responses |
| UPLOAD001 | File Upload | HIGH | Unrestricted file upload |
| GRAPH001 | GraphQL Introspection | MEDIUM | GraphQL schema exposure |

## 🐳 Docker Usage

### Build Image

```bash
docker build -t api-auditor:latest .
```

### Run Scans

```bash
# Basic scan with output mounted
docker run -v $(pwd)/output:/output api-auditor:latest scan https://api.example.com --output /output/report.html

# Using docker-compose with test environment
docker-compose up api-auditor

# Interactive mode
docker run -it api-auditor:latest --help
```

## 🔌 Custom Plugins

Create custom security checks by extending the `SecurityCheck` class:

```python
# ~/.api-auditor/plugins/custom_check.py
from api_security_auditor_pro.core.base_check import BaseCheck

class CustomSecurityCheck(BaseCheck):
    name = "Custom API Security Check"
    severity = "HIGH"
    
    async def execute(self, target: str) -> dict:
        # Your custom check logic
        response = await self.request_builder.get(target)
        
        if "vulnerable" in response.text:
            return {
                "finding": "Custom vulnerability detected",
                "severity": self.severity,
                "remediation": "Apply custom fix"
            }
        return None
```

## 📈 CI/CD Integration

### Jenkins Pipeline

```groovy
pipeline {
    agent any
    stages {
        stage('API Security Audit') {
            steps {
                sh 'pip install api-security-auditor-pro'
                sh 'api-auditor audit --spec openapi.yaml --format junit --output security-report.xml'
                junit 'security-report.xml'
            }
        }
    }
}
```

### GitLab CI

```yaml
security-audit:
  stage: test
  script:
    - pip install api-security-auditor-pro
    - api-auditor audit --spec openapi.yaml --format junit --output security-report.xml
  artifacts:
    reports:
      junit: security-report.xml
```

### GitHub Actions

```yaml
- name: API Security Audit
  run: |
    pip install api-security-auditor-pro
    api-auditor audit --spec openapi.yaml --format json --output security-report.json
```

## 📝 Output Examples

### JSON Output

```json
{
  "target": "https://api.example.com",
  "timestamp": "2024-01-15T10:30:00",
  "vulnerabilities": [
    {
      "check_id": "sql_injection",
      "severity": "CRITICAL",
      "finding": "SQL Injection vulnerability detected",
      "payload": "' OR '1'='1",
      "remediation": "Use parameterized queries/prepared statements"
    }
  ],
  "scan_summary": {
    "checks_performed": 10,
    "total_requests": 245,
    "duration_seconds": 12.34
  }
}
```

### HTML Report

Generates a professional, responsive HTML report with:
- Executive summary dashboard
- Vulnerability heatmap
- Detailed findings with CVSS scoring
- Remediation recommendations
- MITRE ATT&CK mapping

## 🧪 Development Setup

```bash
# Clone repository
git clone https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro.git
cd api-security-auditor-pro

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install development dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run linting
flake8 src tests
black --check src tests
mypy src

# Build documentation
cd docs && make html
```

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](docs/contributing.md) for guidelines.

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## ⚠️ Disclaimer

This tool is for authorized security testing only. Users are responsible for complying with applicable laws and regulations. Always obtain proper authorization before scanning any API.

## 🌟 Support

- 📚 [Documentation](https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/docs)
- 🐛 [Issue Tracker](https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/issues)
- 💬 [Discussions](https://github.com/[YOUR_GITHUB_USERNAME]/api-security-auditor-pro/discussions)

## 🙏 Acknowledgments

- OWASP API Security Top 10
- Burp Suite and OWASP ZAP communities
- All security researchers and contributors

---

**Star ⭐ this repository if you find it useful!**
